#include <fstream>
#include <string>
#include <cstring>
#include<iostream>
#include <bitset>
using namespace std;
#define abs_val(a) {if(a >= 4000) a -= 4000; else a = 4000 - a;}
typedef unsigned short ushort;
typedef unsigned int uint;

const int MAX = 8005;
ushort plaintext[MAX], ciphertext[MAX];
int key51, key53, key52, key54;
ushort tail_key;
uint key;

// SPN sBox and pBox
const unsigned short sBox_4[16] = { 0xe, 0x4, 0xd, 0x1, 0x2, 0xf, 0xb, 0x8, 0x3, 0xa, 0x6, 0xc, 0x5, 0x9, 0x0, 0x7 };
const unsigned short inverse_sBox[16] = { 0xe, 0x3, 0x4, 0x8, 0x1, 0xc, 0xa, 0xf, 0x7, 0xd, 0x9, 0x6, 0xb, 0x2, 0x0, 0x5 };
const unsigned short pos[17] = {
    0x0,
    0x8000, 0x4000, 0x2000, 0x1000,
    0x0800, 0x0400, 0x0200, 0x0100,
    0x0080, 0x0040, 0x0020, 0x0010,
    0x0008, 0x0004, 0x0002, 0x0001
};
const unsigned short pBox[17] = {
    0x0,
    0x8000, 0x0800, 0x0080, 0x0008,
    0x4000, 0x0400, 0x0040, 0x0004,
    0x2000, 0x0200, 0x0020, 0x0002,
    0x1000, 0x0100, 0x0010, 0x0001
};
unsigned short sBox_16[65536], spBox[65536];

void get_spBox() {
    // Ԥ     S  к  P   
    for (int i = 0; i < 65536; ++i) {
        //      sBox_16[i]     4 λ S     չΪ 16 λ
        sBox_16[i] = (sBox_4[i >> 12] << 12) |
            (sBox_4[(i >> 8) & 0xf] << 8) |
            (sBox_4[(i >> 4) & 0xf] << 4) |
            sBox_4[i & 0xf];

        //      spBox[i]
        spBox[i] = 0; //   ʼ  Ϊ 0
        for (int j = 1; j <= 16; ++j) {
            // ͨ  λ       sBox_16[i]  Ķ Ӧλ       spBox
            if (sBox_16[i] & pos[j]) {
                spBox[i] |= pBox[j]; //      spBox[i]
            }
        }
    }
}


ushort binaryStringToUInt(const std::string& binary) {
    ushort result = 0;
    for (char bit : binary) {
        result = (result << 1) | (bit - '0');
    }
    return result;
}

void input(const std::string& filename) {
    std::ifstream file(filename);
    std::string binary;
    for (int i = 1; i <= 8000; ++i) {
        std::getline(file, binary);
        plaintext[i] = binaryStringToUInt(binary);
        std::getline(file, binary);
        ciphertext[i] = binaryStringToUInt(binary);
    }
    file.close();
}

void output() {
    std::cout << "Key51:" << std::bitset<4>(key51) << endl<<"Key53:" << std::bitset<4>(key53);
}

int main() {
    get_spBox();

    //  Ѿ   õ  key52    key54
    key52 = 0x6;
    key54 = 0xf;

    input("spn_pairs.txt");

    bool flag = false;
    ushort u1, u2, u3, u4;
    ushort x_init, y_init, z;
    ushort x[13], y[5];

    // Analyze 1st and 3rd key bits
    int count13[2][16][16], cnt13[16][16];
    memset(count13, 0, sizeof(count13));

    for (int group = 0; group < 8000; ++group) { //    0   ʼ        0   ʼ
        x_init = plaintext[group];
        for (int pos = 0; pos < 12; ++pos) {
            x[pos] = (x_init >> (15 - pos)) & 0x1; // pos    0    11
        }

        y_init = ciphertext[group];
        for (int pos = 0; pos < 4; ++pos) {
            y[pos] = (y_init >> (12 - 4 * pos)) & 0xf; // pos    0    3
        }

        for (int L1 = 0; L1 < 16; ++L1) {
            for (int L2 = 0; L2 < 16; ++L2) {
                //      S  е       
                u1 = inverse_sBox[y[0] ^ L1];
                u2 = inverse_sBox[y[1] ^ key52];
                u3 = inverse_sBox[y[2] ^ L2];
                u4 = inverse_sBox[y[3] ^ key54];

                //      z   ֵ     ¼   
                if (!((x[0] ^ x[1] ^ x[3] ^ (u1 >> 3) ^ (u2 >> 3) ^ (u3 >> 3) ^ (u4 >> 3)) & 0x1)) {
                    count13[0][L1][L2]++;
                }

                if (!((x[8] ^ x[9] ^ x[11] ^ (u1 >> 1) ^ (u2 >> 1) ^ (u3 >> 1) ^ (u4 >> 1)) & 0x1)) {
                    count13[1][L1][L2]++;
                }
            }
        }
    }

    for (int L1 = 0; L1 < 16; ++L1) {
        for (int L2 = 0; L2 < 16; ++L2) {
            abs_val(count13[0][L1][L2]);
            abs_val(count13[1][L1][L2]);
            cnt13[L1][L2] = count13[0][L1][L2] + count13[1][L1][L2];
        }
    }

    int max13 = -1;
    for (int L1 = 0; L1 < 16; ++L1) {
        for (int L2 = 0; L2 < 16; ++L2) {
            if (cnt13[L1][L2] > max13) {
                max13 = cnt13[L1][L2];
                key51 = L1;
                key53 = L2;
            }
        }
    }

    output();
    return 0;
}
