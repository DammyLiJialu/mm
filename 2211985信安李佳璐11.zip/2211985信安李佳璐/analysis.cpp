#include <iostream>
#include <cstring>
#include <fstream>
#include <chrono>
using namespace std;
using namespace chrono;

int S[16] = { 14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7 };
int x[16] = {}; // ����
int y[16] = {}; // ����
int Count[16][16] = {}; // ������

void DecimalToBinary(int decimal, int* binary, int num);

int main()
{
    int S1[16] = {}; // S�е���
    for (int i = 0; i < 16; i++)
    {
        S1[S[i]] = i;
    }

    ifstream input("spn_pairs.txt"); 

  

    int L1[4] = {}; // ������Կ1 
    int L2[4] = {}; // ������Կ2
    int v[16] = {};
    int u[16] = {};

    int n = 8000; // ����

    for (int i = 0; i < n; i++)
    {
        string X, Y;
        input >> X >> Y;

        for (int j = 0; j < 16; j++) {
            x[j] = X[j] - '0';
            y[j] = Y[j] - '0';
        }

        for (int j = 0; j < 16; j++)
        {
            for (int k = 0; k < 16; k++)
            {
                // for(L_1,L_2) <- (0,0) to (F,F)
                DecimalToBinary(j, L1, 3);
                DecimalToBinary(k, L2, 3);

                // ���� v ��ֵ
                for (int l = 0; l < 4; l++) {
                    v[4 + l] = L1[l] ^ y[4 + l]; // L1 �� y �����
                    v[12 + l] = L2[l] ^ y[12 + l]; // L2 �� y �����
                }

                // S-��������
                int temp1 = (v[4] << 3) | (v[5] << 2) | (v[6] << 1) | v[7];
                int temp2 = S1[temp1]; // S-�е�������
                DecimalToBinary(temp2, u, 7);

                temp1 = (v[12] << 3) | (v[13] << 2) | (v[14] << 1) | v[15];
                temp2 = S1[temp1]; // S-�е�������
                DecimalToBinary(temp2, u, 15);

                // ���� z
                int z = x[4] ^ x[6] ^ x[7] ^ u[5] ^ u[7] ^ u[13] ^ u[15];

                // ���¼���
                if (z == 0) Count[j][k]++;
            }
        }
    }
    input.close();

    int max = -1;
    int LL1 = 0, LL2 = 0; 
    for (int i = 0; i < 16; i++)
    {
        for (int j = 0; j < 16; j++)
        {
            Count[i][j] = abs(Count[i][j] - n / 2);
            if (Count[i][j] > max)
            {
                max = Count[i][j];
                LL1 = i;
                LL2 = j;
            }
        }
    }

    cout << "key52:";
    DecimalToBinary(LL1, L1, 3);
    for (int i = 0; i < 4; i++)
    {
        cout << L1[i];
    }
    cout <<endl<< "key54:";
    DecimalToBinary(LL2, L2, 3);
    for (int i = 0; i < 4; i++)
    {
        cout << L2[i];
    }

    return 0;
}

void DecimalToBinary(int decimal, int* binary, int num)
{
    int i = num - 3; // �������λ
    while (decimal > 0)
    {
        binary[num] = decimal % 2;
        decimal /= 2;
        num--;
    }
    while (num >= i) // ��λ��0
    {
        binary[num] = 0;
        num--;
    }
}
